#pragma once
#include <d3d11.h>
#include <string>
#include <wrl/client.h>
#include <WICTextureLoader.h>

namespace RMPG
{
	class Texture2d
	{
	public:
		HRESULT InitializeFromPicture(ID3D11Device* device, std::wstring texpath);
		HRESULT InitializeFromMemory(ID3D11Device* device, int width, int height, const void* data, DXGI_FORMAT format = DXGI_FORMAT_R8G8B8A8_UNORM);
		ID3D11ShaderResourceView* Get() const;
		ID3D11ShaderResourceView* const* GetAddressOf() const;

	private:
		Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> texture;
	};
};
